//
//  SolidsTableViewCell.swift
//  Matherax
//
//  Created by Ikani Lab on 25/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit

class SolidsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
