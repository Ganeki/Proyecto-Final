//
//  ProfileViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 02/12/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ProfileViewController: UIViewController {
    @IBOutlet weak var uName: UILabel!
    @IBOutlet weak var uEmail: UILabel!
    @IBOutlet weak var uPoints: UILabel!
    
    var db: Firestore!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNavBarLogo()
        
        let user = Auth.auth().currentUser
        let settings = FirestoreSettings()
        settings.areTimestampsInSnapshotsEnabled = true
        Firestore.firestore().settings = settings
        db = Firestore.firestore()
        
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            
            let email = user.email
            uEmail.text = email
            //let photoURL = user.photoURL
            let Name = user.displayName
            uName.text = Name
            //toProfile.setTitle(uName, for: .normal)
            
            //[Print Points]
            
            //let userPoints = user?.displayName
            /*
             let dataPoints = db.collection("users").document(userPoints!)
             print("Aquí imprime \(dataPoints)")
             dataPoints.getDocument { (document, error) in
             if let document = document, document.exists {
             let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
             print("Document data: \(dataDescription)")
             } else {
             print("Document does not exist")
             }
             }
             */
            
            let dataPoints = db.collection("users").whereField("username", isEqualTo: Name).getDocuments {(snapshot, error) in
                
                if error != nil {
                    print(error)
                    
                }else {
                    for document in (snapshot?.documents)! {
                        
                        if let name = document.data()["username"] as? String {
                            
                            if let points = document.data()["Points"] as? Int{
                                
                                self.uPoints.text = String (points)
                                print(points)
                            }
                        }
                    }
                }
            }
            //[End print Points]
        }

        
    }
    
    @IBAction func OutButton(_ sender: UIButton) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        performSegue(withIdentifier: "toLoginVC", sender: self)
    }
    
   

}
