//
//  SecondLessonsViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 26/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import ARKit
import SceneKit
import Firebase
import FirebaseAuth

class SecondLessonsViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    @IBOutlet weak var lessonName: UILabel!
    @IBOutlet weak var scnView: ARSCNView!
    
    var vieneDeVistaUno: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //setUpNavigationBarItems()
        //setLogOutButton()
        
        toProfile()
        setNavBarLogo()
        lessonName.text = vieneDeVistaUno
        
        //ARKIT
        /*
        guard ARWorldTrackingConfiguration.isSupported else {
            fatalError("""
                ARKit is not available on this device. For apps that require ARKit
                for core functionality, use the `arkit` key in the key in the
                `UIRequiredDeviceCapabilities` section of the Info.plist to prevent
                the app from installing. (If the app can't be installed, this error
                can't be triggered in a production scenario.)
                In apps where AR is an additive feature, use `isSupported` to
                determine whether to show UI for launching AR experiences.
            """) // For details, see https://developer.apple.com/documentation/arkit
        }
        */
        let configuration = ARWorldTrackingConfiguration()
        //let configuration = AROrientationTrackingConfiguration()
        self.scnView.debugOptions = [ARSCNDebugOptions.showFeaturePoints, ARSCNDebugOptions.showWorldOrigin]
        self.scnView.session.run(configuration)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's AR session.
        scnView.session.pause()
    }
    
    @IBAction func add(_ sender: UIButton) {
        
        let node = SCNNode()
        node.geometry = SCNBox(width: 0.1, height: 0.1, length: 0.1, chamferRadius: 0)
        node.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
        node.position = SCNVector3(0.30,0.30,0.30)
        
        self.scnView.scene.rootNode.addChildNode(node)
        
    }
    
    
    
    @IBAction func actionToQuiz(_ sender: UIButton) {
        checkUser()
    }
    
    func checkUser(){
        if Auth.auth().currentUser != nil {
            // User is signed in.
            // ...
            self.performSegue(withIdentifier: "toQuizButton", sender: nil )
        } else {
            // No user is signed
            let optionMenu = UIAlertController(title: "Something goes wrong!", message: "Please do sign in or create an account", preferredStyle: .alert)
            optionMenu.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(optionMenu, animated: true, completion: nil)
        }
    }


}
