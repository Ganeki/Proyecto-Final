//
//  ViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 25/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//
import UIKit
import Firebase
import FirebaseAuth
class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var solids: UICollectionView!
    @IBOutlet weak var nombre: UILabel!
    
    var solidsLessons = ["Geometry", "Algebra", "Arithmetic", "Graphics", "Math History", "Overview"]
    
    var solidsImages: [UIImage] = [
    
    UIImage(named: "solids1")!,
    UIImage(named: "algebra")!,
    UIImage(named: "arithmetic")!,
    UIImage(named: "graphics")!,
    UIImage(named: "math_history")!,
    UIImage(named: "overview")!
    
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Firebase Stuff
     /*
        let user = Auth.auth().currentUser
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            //let uid = user.uid
            //let email = user.email
            //let photoURL = user.photoURL
            let uName = user.displayName
            nombre.text = uName
        }
    */
        
// Custom Navigation Bar
        //setUpNavigationBarItems()
        //setLogOutButton()
        toProfile()
        setNavBarLogo()
        //setLeftButton()
        
        solids.dataSource = self
        solids.delegate = self
        
        let layout = self.solids.collectionViewLayout as! UICollectionViewFlowLayout
        
        layout.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        layout.minimumInteritemSpacing = 5
        layout.itemSize = CGSize(width: (self.solids.frame.size.width-20)/2, height: self.solids.frame.size.height/2.5 )
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return solidsLessons.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellLessons", for: indexPath) as! SolidsCollectionViewCell
        
        cell.lessonsName.text = solidsLessons[indexPath.row]
        cell.lessons.image = solidsImages[indexPath.row]
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.5
        cell.layer.cornerRadius = 20
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = solids.cellForItem(at: indexPath)
        
        cell?.layer.borderColor = UIColor.gray.cgColor
        cell?.layer.borderWidth = 3
        
        let lessonList = storyboard?.instantiateViewController(withIdentifier: "LessonsViewController") as? LessonsViewController
        lessonList?.lName = solidsLessons[indexPath.item]
        print(solidsLessons[indexPath.item])
        self.navigationController?.pushViewController(lessonList!, animated: true)
        
    }
 
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = solids.cellForItem(at: indexPath)
        
        cell?.layer.borderColor = UIColor.lightGray.cgColor
        cell?.layer.borderWidth = 0.5
        /*
        let lessonList = storyboard?.instantiateViewController(withIdentifier: "LessonsViewController") as? LessonsViewController
        lessonList?.lName = solidsLessons[indexPath.item]
        print(solidsLessons[indexPath.item])
        self.navigationController?.pushViewController(lessonList!, animated: true)
        */
        
    }
    
    @IBAction func logOutUser(_ sender: UIButton) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        navigationController?.popViewController(animated: true)
        
    }
    
}
