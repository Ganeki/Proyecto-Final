//
//  CellTableViewCell.swift
//  Matherax
//
//  Created by Ikani Lab on 26/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit

class CellTableViewCell: UITableViewCell {

    @IBOutlet weak var titulo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //layer.borderWidth = 0.3
        //layer.borderColor = UIColor.lightGray.cgColor
        //layer.backgroundColor = UIColor.init(red: 30, green: 24, blue: 37, alpha: 1).cgColor
        
    }


}
