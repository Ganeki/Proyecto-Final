//
//  LoginViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 26/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Custom Navigation Bar
        setLeftButton()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        // Firebase stuff
        if Auth.auth().currentUser != nil {
            // User is signed in.
            // ...
            self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
        } else {
            // No user is signed in.
            // ...
            return
        }
    }
    
    @IBAction func loginUser(_ sender: UIButton) {
        
        guard let correo = email.text,
            let pass = password.text else { return }
        
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
                
                let optionMenu = UIAlertController(title: "Something goes wrong!", message: error.localizedDescription, preferredStyle: .alert)
                optionMenu.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(optionMenu, animated: true, completion: nil)
            
                
                
            } else {
                self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
            }
        }
        
        
        
        
    }
    

 
}
