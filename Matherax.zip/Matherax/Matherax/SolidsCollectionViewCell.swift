//
//  SolidsCollectionViewCell.swift
//  Matherax
//
//  Created by Ikani Lab on 25/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit

class SolidsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lessons: UIImageView!
    @IBOutlet weak var lessonsName: UILabel!
    
}
