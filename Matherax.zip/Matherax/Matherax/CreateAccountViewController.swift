//
//  CreateAccountViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 26/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase

class CreateAccountViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backToLogin(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func createAccount(_ sender: UIButton) {
        guard let correo = email.text,
            let pass = password.text,
            let username = userName.text else { return }
        print(correo)

        Auth.auth().createUser(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
                print("1")
                let optionMenu = UIAlertController(title: "Something goes wrong!", message: error.localizedDescription, preferredStyle: .alert)
                optionMenu.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(optionMenu, animated: true, completion: nil)
            }
            
            let user = data?.user
            let changeRequest = user?.createProfileChangeRequest()
            changeRequest?.displayName = username
            changeRequest?.commitChanges(completion: { (error) in
                if let error = error{
                    debugPrint(error.localizedDescription)
                    print("2")
                }
            })
            
            guard let userId = user?.uid else { return }
            
            Firestore.firestore().collection("users").document(userId).setData([
                "username" : username,
                "date_created": FieldValue.serverTimestamp()
                ], completion: { (error) in
                    if let error = error {
                        debugPrint(error.localizedDescription)
                        print("3")
                        /*
                         let optionMenu = UIAlertController(title: "Something goes wrong!", message: error.localizedDescription, preferredStyle: .alert)
                         optionMenu.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                         NSLog("The \"OK\" alert occured.")
                         }))
                         self.present(optionMenu, animated: true, completion: nil)
                         */
                        
                        //Esto no debería estar aquí
                        self.navigationController?.popViewController(animated: true)
                    }else{
                        //Hace el registro de usuario correctamente pero no regresa al Login!
                        self.navigationController?.popViewController(animated: true)
                    }
                    
            })
        }

        
        
    }
    
 

}
