//
//  LessonsViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 26/11/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class LessonsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var tableLessons: UITableView!
    
    var lName = ""
    
    var lectures = ["Platonic Solids",
                    "Polygons",
                    "Planes",
                    "Points",
                    "Tiling",
                    "Circular Triangles",
                    "Volumes",
                    "Symmetry",
                    "Trigonometry",
                    "Curves"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        name.text = lName
        
        //setUpNavigationBarItems()
        //setLogOutButton()
        toProfile()
        setNavBarLogo()
        
        // Do any additional setup after loading the view.
    }
/*
    func setUpNavigationBarItems(){
        
        
        setNavBarLogo()
        setLogOutButton()
        
        
    }
    //Logout user function
    @objc public func logOutUserButton(){
        
        print("logOutUserButton is pressed")
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        navigationController?.popViewController(animated: true)
        
    }
    
    private func setNavBarLogo(){
        let logo = UIImage(named: "loginTop")
        let titleImageView = UIImageView(image: logo)
        titleImageView.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        titleImageView.contentMode = .scaleAspectFit
        navigationItem.titleView = titleImageView
        
    }
    private func setLogOutButton(){
        let logOutButton = UIButton(type: .system)
        //logOutButton.setImage(logo?.withRenderingMode(.alwaysOriginal), for: .normal)
        logOutButton.frame = CGRect(x: 0, y: 0, width: 80, height: 40)
        logOutButton.contentMode = .scaleAspectFit
        logOutButton.backgroundColor = UIColor.white
        logOutButton.setTitle("Log out", for: .normal)
        logOutButton.titleLabel?.font = UIFont(name: "Futura", size: 20)
        logOutButton.addTarget(self, action: #selector(logOutUserButton), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: logOutButton)
    }
 */
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lectures.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CellTableViewCell
        
        //cell.backgroundColor = UIColor.red
        cell.titulo.text = lectures[indexPath.row]
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(lectures[indexPath.row])
        
        let cell = tableView.cellForRow(at: indexPath)
        
        cell?.accessoryType = .checkmark
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segunda"{
            
            let indexPath = tableLessons.indexPathForSelectedRow
            
            let destino = segue.destination as! SecondLessonsViewController
            destino.vieneDeVistaUno = lectures[(indexPath?.row)!]
        }
    }
    
    
    
}

