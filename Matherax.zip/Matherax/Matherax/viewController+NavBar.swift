//
//  viewController+NavBar.swift
//  Matherax
//
//  Created by Ikani Lab on 01/12/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

extension UIViewController{
/*
    func setUpNavigationBarItems(){
        
        
        setNavBarLogo()
        setLogOutButton()
        
        
    }
*/
// Go to Profile
    func toProfile(){
        let toProfile = UIButton(type: .system)
        toProfile.frame = CGRect(x: 0, y: 0, width: 120, height: 40)
        toProfile.contentMode = .scaleAspectFit
        //toProfile.backgroundColor = UIColor.init(red: 30/255, green: 24/255, blue: 37/255, alpha: 1)
        toProfile.tintColor = UIColor.darkGray
 
        
        let user = Auth.auth().currentUser
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            //let uid = user.uid
            //let email = user.email
            //let photoURL = user.photoURL
            let uName = user.displayName
            //nombre.text = uName
            toProfile.setTitle(uName, for: .normal)
        }else{toProfile.setTitle("Guest", for: .normal)}
 
        
        toProfile.titleLabel?.font = UIFont(name: "Futura", size: 20)
        toProfile.addTarget(self, action: #selector(profileVC), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: toProfile)
    }

//Profile button
    @objc public func profileVC(){
        let user = Auth.auth().currentUser
        if user != nil {
            performSegue(withIdentifier: "toProfileVC", sender: self)
        }else{
            

            let optionMenu = UIAlertController(title: "Something goes wrong!", message: "Please do sign in or create an account.", preferredStyle: .alert)
            optionMenu.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(optionMenu, animated: true, completion: nil)
            
        }
        
        
        
    }

    
    
    
//Logout user function
    @objc public func logOutUserButton(){
        
        print("logOutUserButton is pressed")
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        navigationController?.popViewController(animated: true)
        
    }
///////////////////
    
     func setNavBarLogo(){
        let logo = UIImage(named: "loginTop")
        let titleImageView = UIImageView(image: logo)
        titleImageView.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        titleImageView.contentMode = .scaleAspectFit
        navigationItem.titleView = titleImageView
        
    }
     func setLogOutButton(){
        let logOutButton = UIButton(type: .system)
        //logOutButton.setImage(logo?.withRenderingMode(.alwaysOriginal), for: .normal)
        logOutButton.frame = CGRect(x: 0, y: 0, width: 80, height: 40)
        logOutButton.contentMode = .scaleAspectFit
        logOutButton.backgroundColor = UIColor.white
        logOutButton.setTitle("Log out", for: .normal)
        logOutButton.titleLabel?.font = UIFont(name: "Futura", size: 20)
        logOutButton.addTarget(self, action: #selector(logOutUserButton), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: logOutButton)
    }
    
    func setLeftButton(){
        let leftButton = UIButton(type: .system)
        
        leftButton.titleLabel?.font = UIFont(name: "Futura", size: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftButton)
    }
//QUIZ ANSWER

    
}
