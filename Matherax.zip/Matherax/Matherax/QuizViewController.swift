//
//  QuizViewController.swift
//  Matherax
//
//  Created by Ikani Lab on 02/12/18.
//  Copyright © 2018 Ikani Lab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class QuizViewController: UIViewController {
    @IBOutlet weak var uPoints: UILabel!
    @IBOutlet weak var labelQuestions: UILabel!
    @IBOutlet weak var correct: UILabel!
    
    var db: Firestore!
    
//[Answer Button]
    @IBAction func answer(_ sender: UIButton) {
        
       // sender.backgroundColor = UIColor.yellow
        
        
        if(sender.tag == Int(rightAnswerPlacement)){
            print("Right")
            points = points + 1
            print(points)
            
            correct.text = "CORRECT!"
            uPoints.text = String (points)
            
            
        }else{
            print("wrong!")
            correct.text = "WRONG!"
        }
        
        if (currentQuestion != questions.count){
            
            newQuestion()
            //sender.backgroundColor = UIColor.yellow
            
        }else{
            
            checkpoint()
            performSegue(withIdentifier: "toProfileVC", sender: self)
            
        }
        
        
    }
    
    
//[Quiz Variables]
    //var questions:[String] = []
    let questions = ["It is composed of six square faces:",
                     "This platonic solid it is describe by the Schafli symbol {4,3}",
                     "It is composed of 12 pentagonal faces:",
                     "__________ it is given by the Wythoff symbol 3|25",
                     "Is the regular polyhedron having 20 equivalent triangle faces:",
                     "It is a polyhedron with four sides",
                     "A square dipyramid with equal edge lengths"]
    
    let answers = [["CUBE","ROMBI", "OCTAHEDRON"],
                   ["HEXAHEDRON","ICOSAHEDRON", "OCTAHEDRON"],
                   ["DODECAHEDRON","TETRAHEDRON", "OCTAHEDRON"],
                   ["DODECAHEDRON", "SPHERE", "SQUARE"],
                   ["ICOSAHEDRON","DIPYRAMID", "PENTAGRAM"],
                   ["TETRAHEDRON", "FRACTAL", "SQUARE"],
                   ["OCTAHEDRON", "TETRAHEDRON", "ICOSAHEDRON"]]
    
    var currentQuestion = 0
    var rightAnswerPlacement:UInt32 = 0
    var points = 0
    var handle: DatabaseHandle?
    



    override func viewDidLoad() {
        super.viewDidLoad()

        let settings = FirestoreSettings()
        settings.areTimestampsInSnapshotsEnabled = true
//[Database Stuff!]
        var ref: DatabaseReference!
        ref = Database.database().reference()
 /*JSON
        handle = ref?.child("Quiz").observe(.childAdded, with: {(snapshot) in
            
            if let item = snapshot.value as? String{
                
                self.questions.append(item)
         
            }
            
        })
*/
        Firestore.firestore().settings = settings
        // [END setup]
        db = Firestore.firestore()
        

        
        
        
        //setUpNavigationBarItems()
        //setLogOutButton()
        newQuestion()
        toProfile()
        setNavBarLogo()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //newQuestion()
        
    }
//[function that displays new question]
    func newQuestion(){
        
        labelQuestions.text = questions[currentQuestion]
        rightAnswerPlacement = arc4random_uniform(3)+1
        
        //Create a button
        var button:UIButton = UIButton()
        var x = 1
        for i in 1...3{
            //Create a button
            button = view.viewWithTag(i) as! UIButton
            //button.backgroundColor = UIColor.yellow
            if (i == Int(rightAnswerPlacement)){
                button.setTitle(answers[currentQuestion][0], for: .normal)
                
            }else{
                button.setTitle(answers[currentQuestion][x], for: .normal)
                x = 2
            }
            
        }
        
        currentQuestion += 1
        
    }
    
    
    
    
    
    @IBAction func updateButton(_ sender: UIButton) {
        
        checkpoint()
        
    }
    
    
    
    func checkpoint(){
        
        let user = Auth.auth().currentUser
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            //let uid = user.uid
            //let email = user.email
            //let photoURL = user.photoURL
            let uIde = user.uid
            //uPoints.text = uIde
            db.collection("users").document(uIde).updateData([
                "Points": points,
                
            ]) { err in
                if let err = err {
                    print("Error updating document: \(err)")
                } else {
                    print("Document successfully updated")
                }
            }
            
            
        }else {print("There's no user")}
        
        

        
    }


}
